package com.example.sign_up

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
